---
name: Proposal
about: Propose a non-trivial change
title: "[Proposal]: Write a descriptive title here"
labels: ''
assignees: ''

---

## Proposal

(A clear and concise description of what the proposal is.)
